package com.geektrust.learning;

public class ConsoleWriter {
    public void writeToConsole(String[] splitInput, int output, int emiLeft) {
        System.out.println(splitInput[1] + " " + splitInput[2] + " " + output + " " + emiLeft);
    }
}
